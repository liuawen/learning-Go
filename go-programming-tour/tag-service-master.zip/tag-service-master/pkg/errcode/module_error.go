package errcode

var (
	ErrorGetTagListFail = NewError(20010001, "获取标签列表失败")
)
