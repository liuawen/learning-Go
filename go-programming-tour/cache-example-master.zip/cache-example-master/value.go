package cache

type Value interface {
	Len() int
}
