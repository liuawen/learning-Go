package global

import (
	"github.com/go-programming-tour-book/blog-service/pkg/validator"
)

var (
	Validator *validator.CustomValidator
)
