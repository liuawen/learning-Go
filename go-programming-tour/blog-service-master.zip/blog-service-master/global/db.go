package global

import "github.com/jinzhu/gorm"

var (
	DBEngine *gorm.DB
)
